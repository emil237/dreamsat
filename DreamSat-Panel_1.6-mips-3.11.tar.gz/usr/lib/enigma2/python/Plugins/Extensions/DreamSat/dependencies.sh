#!/bin/sh

# List of packages to install
PACKAGESPY3=(
    "p7zip"
    "wget"
    "python3-requests"
    "python3-imaging"
    "python3-lxml"
    "python3-multiprocessing"
    "python3-pyexecjs"
    "python3-sqlite3"
    "python3-six"
    "python3-codecs"
    "python3-compression"
    "python3-difflib"
    "python3-xmlrpc"
    "python3-html"
    "python3-misc"
    "python3-shell"
    "python3-twisted-web"
    "python3-unixadmin"
    "python3-compression"
    "python3-treq"
    "python3-core"
    "python3-cryptography"
    "python3-json"
    "python3-netclient"
    "python3-pyopenssl"
    "python3-futures3"
    "libusb-1.0-0"
    "unrar"
    "curl"
    "libxml2"
    "libxslt"
    "enigma2-plugin-systemplugins-serviceapp"
    "rtmpdump"
    "duktape"
    "astra-sm"
    "ffmpeg"
    "exteplayer3"
    "gstplayer"
    "gstreamer1.0-plugins-good"
    "gstreamer1.0-plugins-base"
    "gstreamer1.0-plugins-bad"
    "gstreamer1.0-plugins-ugly"
    "alsa-plugins"
    "alsa-utils"
    "openvpn"
)

PACKAGESPY2=(
    "p7zip"
    "wget"
    "python-imaging"
    "python-lxml"
    "python-requests"
    "python-pyexecjs"
    "python-sqlite3"
    "python-six"
    "python-codecs"
    "python-compression"
    "python-difflib"
    "python-xmlrpc"
    "python-html"
    "python-misc"
    "python-shell"
    "python-subprocess"
    "python-twisted-web"
    "python-unixadmin"
    "python-compression"
    "python-cryptography"
    "python-json"
    "python-netclient"
    "python-pyopenssl"
    "python-futures"
    "libusb-1.0-0"
    "unrar"
    "curl"
    "libxml2"
    "libxslt"
    "kodi-addon-pvr-iptvsimple"
    "enigma2-plugin-systemplugins-serviceapp"
    "python-lzma"
    "rtmpdump"
    "hlsdl"
    "duktape"
    "f4mdump"
    "astra-sm"
    "ffmpeg"
    "exteplayer3"
    "gstplayer"
    "gstreamer1.0-plugins-good"
    "gstreamer1.0-plugins-base"
    "gstreamer1.0-plugins-bad"
    "gstreamer1.0-plugins-ugly"
    "alsa-plugins"
    "alsa-utils"
    "openvpn"
)

sleep 1

echo "Installing Dependencies ..."
echo

sleep 1
# Determine which version of Python is installed
if python --version 2>&1 | grep -q '^Python 3\.'; then
    echo "You have Python3 image"
    echo
    PYTHON='PY3'
else
    echo "You have Python2 image"
    echo
    PYTHON='PY2'
fi
sleep 1
# Function to check if a package is already installed
is_installed() {
    if grep -q "^Package: $1$" /var/lib/opkg/status && grep -q "^Status: install ok installed$" /var/lib/opkg/status; then
        return 0
    else
        return 1
    fi
}

# Function to print package name in red color
print_package_name() {
    echo -e "\033[31m$1\033[0m"
}

SEP="---------------------------------------------------------------------"

# Install packages if they are not already installed
if [ $PYTHON = "PY3" ]; then
    echo "Please Wait Unitil Opkg Update Finish ..."
    echo
    rm -r /run/opkg.lock >/dev/null 2>&1
    rm -r /var/cache/opkg/* >/dev/null 2>&1
    opkg update >/dev/null 2>&1
    echo $SEP
    for PACKAGE in "${PACKAGESPY3[@]}"
    do
        if is_installed "$PACKAGE"; then
            if [ $PYTHON = "PY3" ]; then
                echo "Package [$PACKAGE] is already installed, skipping..."
            fi        
        else
            echo "Installing package '$PACKAGE'..."
            opkg install "$PACKAGE"
        fi
    done
else
    echo "Please Wait Unitil Opkg Update Finish ..."
    echo
    opkg update >/dev/null 2>&1
    echo $SEP
    for PACKAGE in "${PACKAGESPY2[@]}"
    do
        if is_installed "$PACKAGE"; then
            if [ $PYTHON = "PY2" ]; then
                echo "Package '$PACKAGE' is already installed, skipping..."
            fi        
        else
            echo "Installing package '$PACKAGE'..."
            opkg update >/dev/null 2>&1
            opkg install "$PACKAGE"
        fi
    done
fi

#clean cash
rm -r /var/cache/opkg/* >/dev/null 2>&1
rm -r /var/volatile/tmp/opkg* >/dev/null 2>&1

echo ""
echo "##############################################################"
echo "#                 Dependcies INSTALLED SUCCESSFULLY                                 #"
echo "#                            Copyright (C) $(date +'%Y') Linuxsat@                                          #"
echo "##############################################################"

sleep 5

exit 0